package com.ritzCourse.mapper;

import com.ritzCourse.pojo.Shop;

public interface ShopMapper {
    int insert(Shop record);

    int insertSelective(Shop record);
}