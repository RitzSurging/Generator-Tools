package com.ritzCourse.mapper;

import com.ritzCourse.pojo.Users;

public interface UsersMapper {
    int insert(Users record);

    int insertSelective(Users record);
}