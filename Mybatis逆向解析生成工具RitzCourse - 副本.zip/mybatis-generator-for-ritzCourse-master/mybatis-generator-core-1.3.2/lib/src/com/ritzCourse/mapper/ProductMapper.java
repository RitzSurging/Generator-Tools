package com.ritzCourse.mapper;

import com.ritzCourse.pojo.Product;

public interface ProductMapper {
    int insert(Product record);

    int insertSelective(Product record);
}