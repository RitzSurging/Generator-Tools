package com.ritzCourse.mapper;

import com.ritzCourse.pojo.Store;

public interface StoreMapper {
    int insert(Store record);

    int insertSelective(Store record);
}